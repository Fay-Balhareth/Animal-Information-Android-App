package com.example.labquiz2;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
public class MainActivity extends AppCompatActivity {
    private Adapter animalAdapter;
    private GridView animalGridView;
    private static final String[] NamesOfAnimal = { "Panda", "Frog", "Raccoon", "Cat", "Rabbit", "Dog", "Monkey", "Fish" };
    private static final int[] ImgId = { R.drawable.img1, R.drawable.img2, R.drawable.img3, R.drawable.img4, R.drawable.img5, R.drawable.img6, R.drawable.img7, R.drawable.img8 };
    private static final String[] Descriptions = { "Panda, a beloved symbol of China, is known for its striking black and white fur and bamboo diet.",
                                                   "Frogs are amphibians with smooth, moist skin, famous for their croaking sounds.",
                                                   "Raccoons are small to medium-sized mammals with masked faces, known for their curiosity.",
                                                   "Cats are popular domestic pets known for their independence and various breeds.",
                                                   "Rabbits are small mammals with long ears and fluffy tails, commonly kept as pets.",
                                                   "Dogs are known for their loyalty and come in various breeds, serving as companions and working animals.",
                                                   "Monkeys are agile and intelligent primates found in various species across the world.",
                                                   "Fish are aquatic vertebrates with gills, scales, and fins, playing vital roles in aquatic ecosystems." };
    @Override
    protected void onStart() {
        super.onStart();
        displayMessage("Main Activity Started"); }
    @Override
    protected void onResume() {
        super.onResume();
        displayMessage("Main Activity Resumed"); }
    @Override
    protected void onPause() {
        super.onPause();
        displayMessage("Main Activity Paused"); }
    @Override
    protected void onStop() {
        super.onStop();
        displayMessage("Main Activity Stopped"); }
    @Override
    protected void onRestart() {
        super.onRestart();
        displayMessage("Main Activity Restarted"); }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        displayMessage("Main Activity Destroyed"); }
    private void displayMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeActionBar();
        initializeGridView();
        initializeGridViewClickListener();
        SearchView customSearchView = findViewById(R.id.custom_search_view);
        customSearchView.setSearchableInfo(
                ((SearchManager) getSystemService(Context.SEARCH_SERVICE)).getSearchableInfo(getComponentName()) );
        customSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; }
            @Override
            public boolean onQueryTextChange(String searchText) {
                animalAdapter.getFilter().filter(searchText);
                return true; } }); }
    private void initializeActionBar() {
        getSupportActionBar().setTitle("The Animals :"); }
    private void initializeGridView() {
        animalGridView = findViewById(R.id.grid_view);
        animalAdapter = new Adapter(this, NamesOfAnimal, ImgId);
        animalGridView.setAdapter(animalAdapter); }
    private void initializeGridViewClickListener() {
        animalGridView.setOnItemClickListener((parent, view, position, id) -> { navigateToDescriptionActivity(position); }); }
    private void navigateToDescriptionActivity(int position) {
        Intent intent = new Intent(MainActivity.this, Descreption.class);
        try {
            if (animalAdapter.realIds.isEmpty() == false){
                position = animalAdapter.realIds.get(position);
            }
        }
        catch (Exception e) {}


        String namesOfAnimal = NamesOfAnimal[position];
        int imgId = ImgId[position];
        String descriptions = Descriptions[position];
        Bundle extras = new Bundle();
        extras.putString("name", namesOfAnimal);
        extras.putInt("image", imgId);
        extras.putString("description", descriptions);
        intent.putExtras(extras);
        startActivity(intent);
    }

}
