package com.example.labquiz2;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
public class Descreption extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        getSupportActionBar().setTitle("Animals Descrption");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.descriptions);
        Intent intent = getIntent();
        String animalName = intent.getStringExtra("name");
        int animalImageId = intent.getIntExtra("image", 0);
        String animalDescription = intent.getStringExtra("description");
        ImageView imageView = findViewById(R.id.img);
        TextView nameTextView = findViewById(R.id.name);
        TextView descriptionTextView = findViewById(R.id.description);
        imageView.setImageResource(animalImageId);
        nameTextView.setText(animalName);
        descriptionTextView.setText(animalDescription);
    }
}