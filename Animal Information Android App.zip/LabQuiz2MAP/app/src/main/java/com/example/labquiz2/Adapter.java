package com.example.labquiz2;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
public class Adapter extends BaseAdapter implements Filterable {
    private Context c;
    private final String[] names;
    private String[] fNames;
    private final int[] imgId;
    private int[] fImgId;
    public List<Integer> realIds;
    public Adapter(Context context, String[] animalNames, int[] imageIds) {
        this.c = context;
        this.names = animalNames;
        this.imgId = imageIds;
        this.fNames = animalNames.clone();
        this.fImgId = imageIds.clone();
        this.flater = LayoutInflater.from(c); }

    @Override
    public int getCount() {
        return fNames.length;
    }
    @Override
    public Object getItem(int position) {
        return fNames[position];
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    private LayoutInflater flater;
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = flater.inflate(R.layout.items, null);
            holder = new ViewHolder();
            holder.textView = convertView.findViewById(R.id.textView);
            holder.imageView = convertView.findViewById(R.id.imageView);
            convertView.setTag(holder); } else {
            holder = (ViewHolder) convertView.getTag(); }
        holder.textView.setText(fNames[position]);
        holder.imageView.setImageResource(fImgId[position]);
        return convertView; }

    private static class ViewHolder {
        TextView textView;
        ImageView imageView;   }

    private AnimalFilter filter;
    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new AnimalFilter(); }
        return filter; }

    private class AnimalFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<String> filteredList = filterList(charSequence);
            FilterResults results = new FilterResults();
            results.values = filteredList.toArray(new String[0]);
            results.count = filteredList.size();
            return results; }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            applyFilter((String[]) filterResults.values); }
        private List<String> filterList(CharSequence charSequence) {
            List<String> filteredList = new ArrayList<>();

            String filterString = charSequence.toString().toLowerCase();
            List<Integer> filteredImagesList = new ArrayList<>();
            realIds = new ArrayList<>();
            for (int i = 0; i < names.length; i++) {
                if (charSequence == null || charSequence.length() == 0 || names[i].toLowerCase().contains(filterString)) {
                    realIds.add(i);
                    filteredList.add(names[i]);
                    filteredImagesList.add(imgId[i]);  } }
            fImgId = new int[filteredImagesList.size()];
            for (int i = 0; i < filteredImagesList.size(); i++) {
                fImgId[i] = filteredImagesList.get(i); }
            return filteredList; }
        private void applyFilter(String[] filteredNames) {
            fNames = filteredNames;
            notifyDataSetChanged();} }
}

